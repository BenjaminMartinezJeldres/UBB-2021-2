
package tareparadigmas1;


import java.util.Scanner;

import javax.swing.JOptionPane;


public class TareaParadigmas1 {
    
    public static void main(String[]args){
        Scanner entrada= new Scanner(System.in);
       int nElementos;
       
       nElementos= Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad de alumnos "));
        
       String[]name=new String[nElementos];
       
       
        System.out.println("Digite los nombres ");
         for (int i = 0;  i< nElementos; i++) {
             System.out.println((i+1)+"Digite nombre: ");
             name[i]= entrada.next().strip();
             
        }
         System.out.println("\nLos nombres son: ");
         for (int i = 0; i < nElementos; i++) {
             System.out.println(name[i]+" ");
        }
         
         
    
    }
    
   
}
